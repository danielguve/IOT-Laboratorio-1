#include "arduino_secrets.h"

// Pines
const int botonPin = 2;
const int relePin = 8;

bool estadoRele = false;
bool ultimoEstadoBoton = HIGH;

void setup() {
  pinMode(botonPin, INPUT_PULLUP);  
  pinMode(relePin, OUTPUT);
  digitalWrite(relePin, LOW);      
}

void loop() {

  bool estadoBoton = digitalRead(botonPin);

  // Detecta cuando el botÃ³n se presiona
  if (estadoBoton == LOW && ultimoEstadoBoton == HIGH) {
    estadoRele = !estadoRele;             
    digitalWrite(relePin, estadoRele);     
    delay(200);
  }

  ultimoEstadoBoton = estadoBoton;
}